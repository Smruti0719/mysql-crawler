package com.crawler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaDbCrawlerApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaDbCrawlerApplication.class, args);
	}

}
